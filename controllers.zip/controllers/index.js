exports.index = function(req, res) {
  res.send({ title: 'Hello My Friend' });
};
